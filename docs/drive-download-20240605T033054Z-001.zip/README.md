## Folder description - coming 

## Table of documents 

## Help convert the below list to a table 

| Document Name | Description | Link |
| --- | --- | --- |
| AI - book review dt2024.06.03.pdf | eMail - Review of chapter 1 | [Link](https://drive.google.com/open?id=1uG1vDWYd24vjd1StWnNr7yWL0OHB4IqM/view) |
| AI - BUILDING_LLM_POWERED_APPLICATIONS-1905.00537v3 dt2024.06.01.pdf | email - Intro to book | [Link](https://drive.google.com/open?id=1RmsIugNXqEc-lM9HsmH2WkhHj-3ZiZUt/view) |
| AI - discussion dt2024.06.02.pdf | eMail - answering q's from Unni | [Link](https://drive.google.com/open?id=1HAKt4VQzGpcP-o3-YKoS02LDDGJ_Zpy5/view) |
| AI - What is Fine-Tuning of an LLM dt2024.06.01.pdf | eMail - explain Fine tunning as attchment | [Link](https://drive.google.com/open?id=1ZRuBKaWoGyHZtoMU3zvFO9baBT67L3yI/view) |
| Book BUILDING_LLM_POWERED_APPLICATIONS 2.pdf | Book - Building LLM Powred Applications | [Link](https://drive.google.com/open?id=1nHnx2BS4r9Do00MThviD58dsbpgYlvwo/view) |
| NIPS-2017-attention-is-all-you-need-Paper.pdf | Research paper - Attention is all you need | [Link](https://drive.google.com/open?id=1QkXXfid7yotjDZjTm0am2bbT06ItkyIo/view) |
| SuperGLUE - A Stickier Benchmark for GenAI.pdf | Research paper - SuperGLUE a tool-metric to evaluate LLM | [Link](https://drive.google.com/open?id=1kne-GnA47ISIhvRmuz4_P4ghBgCdLsrr/view) |
| The decoder stack in the Transformer model _ by Sandaruwan Herath _ Data Science and Machine Learning _ May, 2024 _ Medium.pdf | Article - Explaining Decoder | [Link](https://drive.google.com/open?id=1wmHe9la8vzYTeRuuzK1GqZmeOEaLG_Wc/view) |
| Transformer — The Encoder Stack Explained _ by Sandaruwan Herath _ Data Science and Machine Learning _ Apr, 2024 _ Medium.pdf | Article - Explaing Encoder | [Link](https://drive.google.com/open?id=1bHY42dTaHEpKftbzf4mv_uRHvX1ev-R3/view) |
| What is Fine-Tuning of an LLM.pdf | Swamy doc explaining Fine-tuning | [Link](https://drive.google.com/open?id=1byCFLLIKqX-wP7twkKfibLKcsgVPcAgO/view) |


